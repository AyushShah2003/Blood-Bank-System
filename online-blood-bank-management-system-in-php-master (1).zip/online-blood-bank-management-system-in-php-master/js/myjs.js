$(document).ready(function() {
    $(".fade-out-5").fadeOut(5000);
});


